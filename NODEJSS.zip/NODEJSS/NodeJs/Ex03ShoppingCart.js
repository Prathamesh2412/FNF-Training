const shoppingcart = require("./CartIIFE")

shoppingcart.additem( {"id":1,"itemName":"Apple","price":500});
shoppingcart.additem( {"id":2,"itemName":"Banana","price":540});     
shoppingcart.additem( {"id":3,"itemName":"oranges","price":780});
shoppingcart.additem( {"id":4,"itemName":"pineapple","price":650}

);

const items = shoppingcart.getAll()
for(var item of items)
    console.log(item)