//immediatly invoked functions self invoking object

module.exports = (function(){
        let cart = [];

        function additem(item){
            cart.push(item);
        }
        function findItem(id){
            return cart.find(s=>s.id == id)
        }

        function removeItem(item){
            var rec = cart.findIndex(s=>s.id==item.id)
            if(index <0)
                throw "not found"
            cart.splice(index,1)
        }

        function getAll(item){
            return cart;
        }
        return{
            additem,findItem,removeItem,getAll
        }
})()