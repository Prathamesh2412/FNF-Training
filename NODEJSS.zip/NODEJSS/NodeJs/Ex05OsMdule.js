const os = require('os');
console.log(os.userInfo());
console.log(os.hostname());
console.log(os.arch());
console.log(os.platform());
console.log("the total uptime is :"+os.uptime()/3600+" "+"hrs");
console.log(os.version());
console.log("the total memory is "+os.totalmem());
console.log("the total cpus with my machine is "+os.cpus().length)