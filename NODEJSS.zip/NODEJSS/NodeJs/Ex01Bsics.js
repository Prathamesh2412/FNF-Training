console.log("Hello world");

const addfunc =(f,s) => (f+s);
const res = addfunc(4,5);
//nodejs does not have inputs from the user as it is a server side programming
console.log(res)


// const Add = (f,s)=>(f+s)
// const sub = (f,s)=>(f-s)
// const mul = (f,s)=>(f*s)
// const div = (f,s)=>(f/s)
// const result = Add(5,3);
// console.log(result)

// const subs = sub(5,3);
// console.log(subs)

// const multi = mul(5,3);
// console.log(multi)

// const divi = div(5,3);
// console.log(divi)

// const z= ["Apple","Banana","oranges","Bread"]
// for(var item of z){
//     console.log(item)
// }

const data = [
    {"id":123,"Name":"Prathamesh","address":"Banglore"},
    {"id":443,"Name":"Ayush","address":"Patna"},
    {"id":323,"Name":"Ezra","address":"Mirzapur"},
    {"id":763,"Name":"Abhishek","address":"Gorakhpur"}
]
for(const rec of data)
    console.log(`${rec.Name} is from ${rec.address} and his id is ${rec.id}`)
    