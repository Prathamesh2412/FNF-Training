//export functions
module.exports.simpleFunction = function(){
    console.log("simple function is created")
}

module.exports.mathTable = function(num = 5){
    console.log(`Multiplication table for ${num}`)
    for(let i = 1;i<=10;i++)
        console.log(`${num} x ${i} = ${num*i}`)
    console.log("*****************ENd of the table**********************")
}

module.exports.book = class{
    constructor(id,title,price){
        this.id = id;
        this.title = title;
        this.price=price;
    }

}