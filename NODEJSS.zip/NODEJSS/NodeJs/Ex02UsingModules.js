const external = require("./CustomModule")

// console.log(external.simpleFunction)
// console.log(external.simpleFunction())
// console.log(external.mathTable())

const myBook = new external.book(11,"2 states",600);
console.log(myBook)

const book = new external.book(12,"3 idiots",200);
console.log(book)