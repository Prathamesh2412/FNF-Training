const http=require('http')
const fs=require("fs")
const root=__dirname;//Directory of the Application
const portNo=1234
 
http.createServer((req,res)=>{
 
        const url=req.url
        if(url!=="/favicon.ico")
        {
            if(url=="/Welcome")
        {
        res.write("<h1> Welcome to Node JS</h1>")
        res.write("<h1> The requested url was:"+ url)
        res .end()
        }
        else if("/ClientApp")
        {
            const filename=root+"/ClientApp.html"
            fs.createReadStream(filename).pipe(res)
            return
        }
    }
}).listen(portNo);
 
console.log(`Server is available at port:${portNo}`)