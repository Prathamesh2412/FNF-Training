// const http = require("http")
// const fs = require('fs')
// const parse = require("url").parse;
// const portno = 1234
// const root = __dirname;
// const data = require("./mydata.json");
// const empList=[]

// function errorPage(res){
//     const file = root + "/ErrorPage.html"
//     fs.createReadStream(file).pipe(res);
// }

// function processGet(req,res){
//         let query = parse(req.url,true).query;
//         var rec = {"name":query.username,"email":query.useremail}
//         empList.push(rec);
//         const msg = `<p>thank you for registering with us!!</p><p>Mr.${query.username}'s email address is ${query.useremail}</p>`
//         res.write(msg);
//         res.end()
// }
// function addata(req,res){   
    
//         let data = `${JSON.stringify(empList)}`;
//         fs.appendFileSync("SampleData.json",data,'utf-8')
// }

// http.createServer((req, res) => {
//    console.log(req.method)
//     if(req.method =="GET"){
//         const query = parse(req.url).query;
//         if(query!=null){
//         processGet(req,res)
//         addata(req,res)  
//         return;
//         }          
//     }
//             switch(req.url){
//                 case "/EmpList":
                    
//                     res.write(JSON.stringify(empList));
//                     break;
//                 case "/EmpData":
//                     res.write(JSON.stringify(data))
//                 break;
//                 case "/Registor":
//                     fs.createReadStream(root+ "/RegistrationPage.html").pipe(res)
                    
//                     return
//                 default:
//                     errorPage(res);
//                 return;
//             }
// res.end()
// }).listen(portno);
// console.log("server is available at 1234")











const http = require("http");
const fs = require('fs');
const parse = require("url").parse;
const portno = 1234;
const root = __dirname;
const data = require("./mydata.json");
const empList = [];

function errorPage(res) {
    const file = root + "/ErrorPage.html";
    fs.createReadStream(file).pipe(res);
}

function processGet(req, res) {
    let query = parse(req.url, true).query;
    var rec = { "name": query.username, "email": query.useremail };
    empList.push(rec);
    const msg = `<p>Thank you for registering with us!!</p><p>Mr.${query.username}'s email address is ${query.useremail}</p>`;
    res.write(msg);
    res.end();
}

function addata() {
    fs.writeFileSync("SampleData.json", JSON.stringify(empList, null, 2), 'utf-8');
}

http.createServer((req, res) => {
    console.log(req.method);
    if (req.method == "GET") {
        const query = parse(req.url).query;
        if (query != null) {
            processGet(req, res);
            addata();
            return;
        }
    }
    switch (req.url) {
        case "/EmpList":
            res.write(JSON.stringify(empList));
            break;
        case "/EmpData":
            res.write(JSON.stringify(data));
            break;
        case "/Register":
            fs.createReadStream(root + "/RegistrationPage.html").pipe(res);
            return;
        default:
            errorPage(res);
            return;
    }
    res.end();
}).listen(portno);

console.log("Server is available at port 1234");
