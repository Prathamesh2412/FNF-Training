//std module will not have ./

const fs = require('fs'); //this is how we import a module in node js

// const fileName = "C:/Users/6147953/Desktop/NodeJs/Ex03ShoppingCart.js";

// // Reading //////////////

// fs.readFile(fileName, 'utf-8', (err, data) => {
//     if (err) {
//         console.log(err.message);
//     } else {
//         console.log(data);
//     }
//     console.log("file reading is complete");
// });


// console.log("file reading is going on")

// const contents = fs.readFileSync(fileName,"utf-8");
// console.log(contents);


const obj = {};
obj.id =123;obj.name="testName";obj.address="testAddress";
let data = `${JSON.stringify(obj)}`;
fs.appendFileSync("SampleData.json",data,'utf-8')