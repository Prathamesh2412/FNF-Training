const express = require("express")
const app = express();

app.get("/",(req,res)=>res.write("Home Page"))
app.get("/Employees",(req,res)=>res.send("EMployee Page"))
app.get("/Customers",(req,res)=>res.send("Customers Page"))
app.get("/Orders",(req,res)=>res.send("Orders Page"))
app.get("/About Us",(req,res)=>res.send("About Us Page"))
app.get("/Registration",(req,res)=>{
    res.sendFile(__dirname + "/RegistrationPage.html")
})
app.listen(1234, ()=>{
    console.log("Server at 1234")
});