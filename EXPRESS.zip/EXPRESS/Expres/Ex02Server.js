const express = require("express")
const app = express();
const root = __dirname;

function isAuthenticated(req,res,next){
    console.log("the request is authenticated")
    next()
}

app.use(express.urlencoded({extended :false}))
app.use(isAuthenticated)


app.get("/Registor",(req,res)=>{
    res.sendFile(root + "/RegistrationPage.html")
})
app.get("/processRegistor",(req,res)=>{
    const content =req.query;
    res.send(content);
})

app.post("/postRegistor",(req,res)=>{
    const {username,useremail}=req.body
    const msg = `<h1>Details of the registored user</h1><p>The Name entered is ${username} and the email Address is ${useremail} `;
    res.send(msg);

})
app.listen(1234,()=>{
        console.log("server is available at port:1234")
});